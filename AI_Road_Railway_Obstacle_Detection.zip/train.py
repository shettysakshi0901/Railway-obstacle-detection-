from ultralytics import YOLO

# Change this path if your dataset is stored elsewhere.
DATA_YAML = r"C:\Users\ACER\Downloads\Railway track obstacle detection.v1i.yolov8\data.yaml"

model = YOLO("yolov8n.pt")

model.train(
    data=DATA_YAML,
    epochs=20,
    imgsz=640
)

print("Training completed.")
