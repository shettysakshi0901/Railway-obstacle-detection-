# AI-Based Road & Railway Obstacle Detection and Alert System

## Project objective

This project uses YOLOv8 and OpenCV to detect road and railway obstacles from video.

The trained model detects six classes:

- Animal
- Car
- Person
- Rock
- Trash
- Tree

For the railway scenario, the planned safety logic is to determine whether a detected person is inside the railway track danger region before generating a railway obstacle alert.

The current braking response is a software simulation. No physical brake hardware is controlled.

## Project workflow

Camera / Video
        ↓
OpenCV
        ↓
YOLOv8
        ↓
Object + Confidence + Bounding Box
        ↓
Danger / Track Decision
        ↓
Alert
        ↓
Braking Simulation

## Folder structure

```text
AI_Road_Railway_Obstacle_Detection/
│
├── process_video.py
├── train.py
├── test_images.py
├── requirements.txt
├── README.md
├── .gitignore
│
├── model/
│   └── best.pt
│
├── video/
│   └── complex1.mp4
│
├── dataset/
│   ├── data.yaml
│   ├── train/
│   ├── valid/
│   └── test/
│
├── docs/
│   └── project_notes.md
│
└── runs/
```

## Setup

Install the required packages:

```bash
pip install -r requirements.txt
```

## Trained model

Place the trained YOLO model here:

```text
model/best.pt
```

`best.pt` is the trained checkpoint produced after YOLOv8 training.

## Video

Place the project video here:

```text
video/complex1.mp4
```

## Run the trained model on the video

```bash
python process_video.py
```

Press `Q` to stop the video.

## Training

The training script uses YOLOv8 Nano:

```text
Model: YOLOv8n
Epochs: 20
Image size: 640 × 640
```

Before training, update `DATA_YAML` in `train.py` to the location of your dataset's `data.yaml`.

Run:

```bash
python train.py
```

After training, copy the generated best checkpoint into:

```text
model/best.pt
```

## Testing

Place the test images under:

```text
dataset/test/images/
```

Then run:

```bash
python test_images.py
```

## Dataset

The project uses the Railway Track Obstacle Detection dataset obtained from Roboflow in YOLO-compatible format.

The dataset classes are:

```text
0 - Animal
1 - Car
2 - Person
3 - Rock
4 - Trash
5 - Tree
```

## Railway safety decision

YOLO detection alone does not determine whether a person is on the railway track.

The planned decision layer is:

```text
Person detected
      ↓
Get bounding box
      ↓
Find bottom-center point
      ↓
Check track danger ROI
      ↓
Outside → ignore railway intrusion
Inside  → alert + braking simulation
```

## Limitations

- Braking is currently simulated in software.
- No physical train/vehicle control is connected.
- Distance estimation is not currently implemented.
- Object tracking is not currently implemented.
- Railway track ROI decision needs to be configured for the selected camera/video view.
- Model performance depends on the training data.

## Future enhancements

- Object tracking
- Distance estimation
- Time-to-collision estimation
- Risk prediction
- GPS and emergency notification
- Dashboard/cloud monitoring
- Multiple cameras
- Hardware integration after safety validation
