Training and prediction outputs can be generated here. Large generated files are ignored by Git.
