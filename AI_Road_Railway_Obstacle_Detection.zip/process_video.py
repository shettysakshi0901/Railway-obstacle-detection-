from ultralytics import YOLO
import cv2
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "model", "best.pt")
VIDEO_PATH = os.path.join(BASE_DIR, "video", "complex1.mp4")

if not os.path.exists(MODEL_PATH):
    print("ERROR: model/best.pt was not found.")
    raise SystemExit

if not os.path.exists(VIDEO_PATH):
    print("ERROR: video/complex1.mp4 was not found.")
    raise SystemExit

model = YOLO(MODEL_PATH)
cap = cv2.VideoCapture(VIDEO_PATH)

if not cap.isOpened():
    print("ERROR: Could not open complex1.mp4")
    raise SystemExit

print("Video opened successfully.")
print("Press Q to stop.")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    results = model.predict(frame, conf=0.50, verbose=False)
    annotated = results[0].plot()

    cv2.imshow("AI Road and Railway Obstacle Detection", annotated)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
print("Video processing completed.")
