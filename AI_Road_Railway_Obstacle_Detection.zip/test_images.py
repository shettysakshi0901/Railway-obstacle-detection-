from ultralytics import YOLO
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "model", "best.pt")
TEST_DIR = os.path.join(BASE_DIR, "dataset", "test", "images")

if not os.path.exists(MODEL_PATH):
    print("ERROR: Put best.pt in model/")
    raise SystemExit

if not os.path.exists(TEST_DIR):
    print("ERROR: Put test images in dataset/test/images/")
    raise SystemExit

model = YOLO(MODEL_PATH)
model.predict(source=TEST_DIR, conf=0.50, save=True)

print("Test-image prediction completed.")
